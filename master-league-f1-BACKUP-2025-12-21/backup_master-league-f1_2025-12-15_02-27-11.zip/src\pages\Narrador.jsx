import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../supabaseClient';
import Dashboard from './Dashboard';
import '../index.css';

function Narrador() {
    const navigate = useNavigate();
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [pilotoSelecionado, setPilotoSelecionado] = useState(null);
    const [pilotosList, setPilotosList] = useState([]);
    const [filtroNome, setFiltroNome] = useState('');
    const [filtroEquipe, setFiltroEquipe] = useState('');
    const [filtroGrid, setFiltroGrid] = useState('');

    // Verificar se já está autenticado
    useEffect(() => {
        const checkAuth = () => {
            const savedAuth = localStorage.getItem('ml_narrador_auth');
            if (savedAuth === 'true') {
                setIsAuthenticated(true);
                carregarPilotos();
            }
        };
        checkAuth();
    }, []);

    const carregarPilotos = async () => {
        try {
            const { data, error } = await supabase
                .from('pilotos')
                .select('id, nome, email, equipe, grid, tipo_piloto, status')
                .order('nome', { ascending: true });

            if (error) throw error;
            setPilotosList(data || []);
        } catch (err) {
            console.error('Erro ao carregar pilotos:', err);
            setError('Erro ao carregar lista de pilotos');
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            // Buscar narrador pelo email
            const { data: narrador, error: fetchError } = await supabase
                .from('narradores')
                .select('*')
                .eq('email', email.toLowerCase().trim())
                .eq('ativo', true)
                .single();

            if (fetchError || !narrador) {
                setError('Email ou senha incorretos');
                setLoading(false);
                return;
            }

            // Verificar senha (SHA-256)
            const encoder = new TextEncoder();
            const data = encoder.encode(senha);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

            if (hashHex !== narrador.senha_hash) {
                setError('Email ou senha incorretos');
                setLoading(false);
                return;
            }

            // Autenticação bem-sucedida
            localStorage.setItem('ml_narrador_auth', 'true');
            setIsAuthenticated(true);
            await carregarPilotos();
        } catch (err) {
            console.error('Erro no login:', err);
            setError('Erro ao fazer login. Tente novamente.');
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('ml_narrador_auth');
        setIsAuthenticated(false);
        setPilotoSelecionado(null);
        setPilotosList([]);
    };

    const pilotosFiltrados = pilotosList.filter(piloto => {
        const nomeMatch = !filtroNome || piloto.nome?.toLowerCase().includes(filtroNome.toLowerCase());
        const equipeMatch = !filtroEquipe || piloto.equipe?.toLowerCase().includes(filtroEquipe.toLowerCase());
        const gridMatch = !filtroGrid || piloto.grid?.toLowerCase() === filtroGrid.toLowerCase();
        return nomeMatch && equipeMatch && gridMatch;
    });

    // Tela de login
    if (!isAuthenticated) {
        return (
            <div className="page-wrapper">
                <div style={{
                    maxWidth: '400px',
                    margin: '100px auto',
                    background: '#1E293B',
                    padding: '40px',
                    borderRadius: '16px',
                    textAlign: 'center',
                    border: '1px solid #06B6D4'
                }}>
                    <h1 style={{ color: '#06B6D4', marginBottom: '20px' }}>ÁREA DO NARRADOR</h1>
                    <p style={{ color: '#94A3B8', marginBottom: '30px' }}>
                        Acesso somente leitura aos painéis dos pilotos
                    </p>
                    <form onSubmit={handleLogin}>
                        <input
                            type="email"
                            placeholder="Email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            required
                            style={{
                                width: '100%',
                                padding: '12px',
                                marginBottom: '15px',
                                borderRadius: '8px',
                                border: 'none',
                                background: '#0F172A',
                                color: 'white'
                            }}
                        />
                        <input
                            type="password"
                            placeholder="Senha"
                            value={senha}
                            onChange={e => setSenha(e.target.value)}
                            required
                            style={{
                                width: '100%',
                                padding: '12px',
                                marginBottom: '20px',
                                borderRadius: '8px',
                                border: 'none',
                                background: '#0F172A',
                                color: 'white'
                            }}
                        />
                        {error && (
                            <div style={{
                                color: '#EF4444',
                                marginBottom: '15px',
                                fontSize: '0.9rem'
                            }}>
                                {error}
                            </div>
                        )}
                        <button
                            type="submit"
                            className="btn-primary"
                            disabled={loading}
                            style={{
                                width: '100%',
                                background: '#06B6D4',
                                color: '#0F172A',
                                cursor: loading ? 'not-allowed' : 'pointer',
                                opacity: loading ? 0.6 : 1
                            }}
                        >
                            {loading ? 'ENTRANDO...' : 'ENTRAR'}
                        </button>
                    </form>
                    <button
                        onClick={() => navigate('/')}
                        style={{
                            marginTop: '20px',
                            width: '100%',
                            padding: '10px',
                            background: 'transparent',
                            border: '1px solid #64748B',
                            color: '#94A3B8',
                            borderRadius: '8px',
                            cursor: 'pointer'
                        }}
                    >
                        Voltar para Home
                    </button>
                </div>
            </div>
        );
    }

    // Tela principal com filtros e visualização
    if (!pilotoSelecionado) {
        return (
            <div className="page-wrapper">
                <div style={{ maxWidth: '1400px', margin: '40px auto', padding: '0 20px' }}>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '30px',
                        borderBottom: '1px solid rgba(255,255,255,0.1)',
                        paddingBottom: '20px'
                    }}>
                        <h1 style={{
                            fontSize: '2rem',
                            fontWeight: '900',
                            color: '#06B6D4',
                            fontStyle: 'italic',
                            margin: 0
                        }}>
                            PAINEL <span style={{ color: 'white' }}>NARRADOR</span>
                        </h1>
                        <button
                            onClick={handleLogout}
                            className="btn-outline"
                            style={{
                                fontSize: '0.8rem',
                                padding: '8px 20px',
                                borderColor: '#EF4444',
                                color: '#EF4444'
                            }}
                        >
                            SAIR
                        </button>
                    </div>

                    <div style={{
                        background: '#1E293B',
                        padding: '20px',
                        borderRadius: '12px',
                        marginBottom: '30px'
                    }}>
                        <h3 style={{ color: '#F8FAFC', marginBottom: '20px' }}>Filtros</h3>
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                            gap: '15px'
                        }}>
                            <div>
                                <label style={{ color: '#94A3B8', fontSize: '0.9rem', display: 'block', marginBottom: '5px' }}>
                                    Nome do Piloto
                                </label>
                                <input
                                    type="text"
                                    placeholder="Buscar por nome..."
                                    value={filtroNome}
                                    onChange={e => setFiltroNome(e.target.value)}
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        borderRadius: '6px',
                                        border: '1px solid rgba(255,255,255,0.2)',
                                        background: '#0F172A',
                                        color: 'white'
                                    }}
                                />
                            </div>
                            <div>
                                <label style={{ color: '#94A3B8', fontSize: '0.9rem', display: 'block', marginBottom: '5px' }}>
                                    Equipe
                                </label>
                                <input
                                    type="text"
                                    placeholder="Buscar por equipe..."
                                    value={filtroEquipe}
                                    onChange={e => setFiltroEquipe(e.target.value)}
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        borderRadius: '6px',
                                        border: '1px solid rgba(255,255,255,0.2)',
                                        background: '#0F172A',
                                        color: 'white'
                                    }}
                                />
                            </div>
                            <div>
                                <label style={{ color: '#94A3B8', fontSize: '0.9rem', display: 'block', marginBottom: '5px' }}>
                                    Grid
                                </label>
                                <select
                                    value={filtroGrid}
                                    onChange={e => setFiltroGrid(e.target.value)}
                                    style={{
                                        width: '100%',
                                        padding: '10px',
                                        borderRadius: '6px',
                                        border: '1px solid rgba(255,255,255,0.2)',
                                        background: '#0F172A',
                                        color: 'white'
                                    }}
                                >
                                    <option value="">Todos</option>
                                    <option value="carreira">Carreira</option>
                                    <option value="light">Light</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div style={{
                        background: '#1E293B',
                        borderRadius: '12px',
                        overflow: 'hidden'
                    }}>
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                            gap: '15px',
                            padding: '20px'
                        }}>
                            {pilotosFiltrados.length === 0 ? (
                                <div style={{
                                    gridColumn: '1 / -1',
                                    padding: '40px',
                                    textAlign: 'center',
                                    color: '#94A3B8'
                                }}>
                                    Nenhum piloto encontrado com os filtros selecionados.
                                </div>
                            ) : (
                                pilotosFiltrados.map(piloto => (
                                    <div
                                        key={piloto.id}
                                        onClick={() => setPilotoSelecionado(piloto)}
                                        style={{
                                            background: 'rgba(6, 182, 212, 0.1)',
                                            border: '1px solid rgba(6, 182, 212, 0.3)',
                                            borderRadius: '8px',
                                            padding: '20px',
                                            cursor: 'pointer',
                                            transition: 'all 0.3s',
                                            ':hover': {
                                                background: 'rgba(6, 182, 212, 0.2)',
                                                borderColor: '#06B6D4'
                                            }
                                        }}
                                        onMouseEnter={(e) => {
                                            e.currentTarget.style.background = 'rgba(6, 182, 212, 0.2)';
                                            e.currentTarget.style.borderColor = '#06B6D4';
                                        }}
                                        onMouseLeave={(e) => {
                                            e.currentTarget.style.background = 'rgba(6, 182, 212, 0.1)';
                                            e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.3)';
                                        }}
                                    >
                                        <div style={{
                                            fontWeight: '800',
                                            color: 'white',
                                            fontSize: '1.1rem',
                                            marginBottom: '10px'
                                        }}>
                                            {piloto.nome || 'Sem Nome'}
                                        </div>
                                        <div style={{ fontSize: '0.85rem', color: '#94A3B8', marginBottom: '5px' }}>
                                            {piloto.equipe || 'Sem Equipe'}
                                        </div>
                                        <div style={{
                                            fontSize: '0.8rem',
                                            textTransform: 'uppercase',
                                            fontWeight: '700',
                                            color: '#06B6D4'
                                        }}>
                                            {piloto.grid || '-'}
                                        </div>
                                        {piloto.tipo_piloto === 'ex-piloto' && (
                                            <div style={{
                                                fontSize: '0.75rem',
                                                color: '#94A3B8',
                                                marginTop: '5px'
                                            }}>
                                                📜 EX-PILOTO
                                            </div>
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // Visualização do painel do piloto (somente leitura)
    return (
        <div>
            <div style={{
                position: 'fixed',
                top: '20px',
                left: '20px',
                zIndex: 1000,
                display: 'flex',
                gap: '10px'
            }}>
                <button
                    onClick={() => setPilotoSelecionado(null)}
                    className="btn-primary"
                    style={{
                        background: '#06B6D4',
                        color: '#0F172A',
                        padding: '10px 20px',
                        borderRadius: '8px',
                        border: 'none',
                        cursor: 'pointer',
                        fontWeight: '700'
                    }}
                >
                    ← Voltar para Lista
                </button>
                <button
                    onClick={handleLogout}
                    className="btn-outline"
                    style={{
                        borderColor: '#EF4444',
                        color: '#EF4444',
                        padding: '10px 20px',
                        borderRadius: '8px',
                        cursor: 'pointer'
                    }}
                >
                    Sair
                </button>
            </div>
            <div style={{ pointerEvents: 'none' }}>
                <Dashboard isReadOnly={true} pilotoEmail={pilotoSelecionado.email} />
            </div>
        </div>
    );
}

export default Narrador;


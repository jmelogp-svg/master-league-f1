export default function Noticias() {
    return <div style={{padding:'100px', textAlign:'center', color:'white'}}><h1>NOTÍCIAS</h1><p>Em construção...</p></div>;
}
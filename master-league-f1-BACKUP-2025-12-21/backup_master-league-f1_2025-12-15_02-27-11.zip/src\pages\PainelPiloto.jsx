import React from 'react';

const PainelPiloto = () => {
  return (
    <div>
      <h1>Painel do Piloto</h1>
      <p>Esta é a página do painel do piloto.</p>
    </div>
  );
};

export default PainelPiloto;
